import "./App.scss";
import Profile from "./components/profile/Profile";

function App() {
  return (
    <div>
      <Profile />
    </div>
  );
}

export default App;

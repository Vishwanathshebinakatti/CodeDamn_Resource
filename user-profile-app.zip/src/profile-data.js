export const profileData = [
  {
    id: 1,
    name: "Susan B",
    job: "Developer Advocate",
    img: "https://i.ibb.co/kXjQ7bH/Portrait-of-a-happy-young-woman-at-home.jpg",
  },
  {
    id: 2,
    name: "John Doe",
    job: "UI/UX Designer",
    img: "https://i.ibb.co/YjX5Rfq/profile2.png",
  },
  {
    id: 3,
    name: "Sarah K",
    job: "FrontEnd Developer",
    img: "https://i.ibb.co/3yhc4WT/profile3.png",
  },
  {
    id: 4,
    name: "Zino A",
    job: "JavaScript Developer",
    img: "https://i.ibb.co/7rcbH2C/profile4.png",
  },
  {
    id: 5,
    name: "Chioma A",
    job: "Fullstack Developer",
    img: "https://i.ibb.co/3hb0Dcm/profile5.png",
  },
];
